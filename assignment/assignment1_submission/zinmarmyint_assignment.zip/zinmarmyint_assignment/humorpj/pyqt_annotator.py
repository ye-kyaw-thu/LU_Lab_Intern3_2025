import sys
import os
import re
from PyQt5.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QLabel, 
                            QLineEdit, QTextEdit, QPushButton, QRadioButton, QButtonGroup,
                            QWidget, QFileDialog, QMessageBox)

LABELS = ["self-deprecate", "self-enhance", "aggression", "affiliation"]

class AnnotationTool(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file_path = ""
        self.data = []
        self.index = 0
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Hartha Humor Style Classification Annotation")
        self.setGeometry(100, 100, 800, 600)

        # Main widget
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout()

        # File selection
        file_layout = QHBoxLayout()
        self.file_path_input = QLineEdit()
        self.file_path_input.setPlaceholderText("dataset.tsv")
        file_layout.addWidget(self.file_path_input)

        self.create_btn = QPushButton("Create New File")
        self.create_btn.clicked.connect(self.create_file)
        file_layout.addWidget(self.create_btn)

        self.load_btn = QPushButton("Load Existing File")
        self.load_btn.clicked.connect(self.load_file)
        file_layout.addWidget(self.load_btn)
        layout.addLayout(file_layout)

        # Annotation area
        self.page_number = QLabel("Page: 0/0")
        layout.addWidget(self.page_number)

        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("Title")
        self.title_input.setFixedHeight(40)
        layout.addWidget(QLabel("Title:"))
        layout.addWidget(self.title_input)

        self.text_input = QTextEdit()
        self.text_input.setPlaceholderText("Text")
        self.text_input.setFixedHeight(150)
        layout.addWidget(QLabel("Text:"))
        layout.addWidget(self.text_input)

        # Clean buttons
        clean_btn_layout = QHBoxLayout()
        
        self.clean_unseen_btn = QPushButton("Clean Unseen")
        self.clean_unseen_btn.clicked.connect(self.clean_unseen_chars)
        clean_btn_layout.addWidget(self.clean_unseen_btn)
        
        self.clean_space_btn = QPushButton("Clean Space")
        self.clean_space_btn.clicked.connect(self.clean_extra_spaces)
        clean_btn_layout.addWidget(self.clean_space_btn)
        
        self.clean_nonburmese_btn = QPushButton("Clean NonBurmese")
        self.clean_nonburmese_btn.clicked.connect(self.clean_non_burmese)
        clean_btn_layout.addWidget(self.clean_nonburmese_btn)
        
        layout.addLayout(clean_btn_layout)

        # Radio buttons for labels
        layout.addWidget(QLabel("Label:"))
        self.label_group = QButtonGroup()
        for i, label in enumerate(LABELS):
            radio = QRadioButton(label)
            self.label_group.addButton(radio, i)
            layout.addWidget(radio)
        self.label_group.button(0).setChecked(True)

        self.punchline_input = QTextEdit()
        self.punchline_input.setPlaceholderText("Punchline")
        layout.addWidget(QLabel("Punchline:"))
        layout.addWidget(self.punchline_input)

        self.save_btn = QPushButton("Save")
        self.save_btn.clicked.connect(self.save_entry)
        layout.addWidget(self.save_btn)

        # Navigation
        nav_layout = QHBoxLayout()
        self.prev_btn = QPushButton("Previous")
        self.prev_btn.clicked.connect(self.go_prev)
        nav_layout.addWidget(self.prev_btn)

        self.next_btn = QPushButton("Next")
        self.next_btn.clicked.connect(self.go_next)
        nav_layout.addWidget(self.next_btn)
        layout.addLayout(nav_layout)

        main_widget.setLayout(layout)

    # Utility methods
    def clean_unseen_chars(self):
        text = self.text_input.toPlainText()

        # Unicode representations for special characters
        zwnj = '\u200C'  # Zero Width Non-Joiner
        zwsp = '\u200B'  # Zero Width Space
        hsp = '\u00AD'   # Half Space (Soft Hyphen)
        soft_hyphen = '\u00AD'
        word_joiner = '\u2060'
        backspace = '\u0008'
        object_replacement_character = '\uFEFF'

        # Combine all special invisible characters into one string
        special_chars = zwnj + zwsp + hsp + soft_hyphen + word_joiner + backspace + object_replacement_character

        # Remove special invisible characters
        cleaned = re.sub(f'[{re.escape(special_chars)}]', '', text)
        self.text_input.setPlainText(cleaned)

    def clean_extra_spaces(self):
        text = self.text_input.toPlainText()

        # Replace tabs and newlines with space
        text = text.replace('\n', ' ').replace('\t', ' ')

        # Collapse multiple spaces to a single space
        cleaned_text = re.sub(r'\s+', ' ', text).strip()

        # Update the text box
        self.text_input.setPlainText(cleaned_text)


    def clean_non_burmese(self):
        text = self.text_input.toPlainText()

        # Allow Burmese, numbers, quotes
        allowed_number_range = '၀၁၂၃၄၅၆၇၈၉'
        allowed_burmese_range = 'က-အ'
        additional_allowed_chars = 'ျြွှောါိီုူဲံ့း်္ဿဣဤဥဦဧဩဪ၌၍၏၎'
        allowed_quote_chars = "\"'"
        preserve_structure_chars = ' '  # Only space; removed '\n'

        # Build final pattern to exclude unwanted characters
        removal_pattern = f'[^{allowed_number_range}{allowed_burmese_range}{additional_allowed_chars}{allowed_quote_chars}{preserve_structure_chars}]'

        text = text.replace("\“", "\"").replace("\‘", "\'")

        # Remove unwanted characters
        cleaned_text = re.sub(removal_pattern, '', text)
        self.text_input.setPlainText(cleaned_text)

    def load_data(self, file_path):
        if not os.path.exists(file_path):
            return []
        with open(file_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip()]

    def save_data(self, file_path, data):
        with open(file_path, 'w', encoding='utf-8') as f:
            for line in data:
                f.write(line + '\n')

    def initialize(self, file_path, create_new):
        self.file_path = file_path
        if create_new:
            open(self.file_path, 'w', encoding='utf-8').close()
            self.data = []
            self.index = 0
        else:
            self.data = self.load_data(self.file_path)
            self.index = len(self.data) if self.data else 0
        self.update_fields()

    def update_fields(self):
        if self.index < len(self.data):
            parts = self.data[self.index].split('\t')
            while len(parts) < 4:
                parts.append("")
        else:
            parts = ["", "", "", ""]

        self.title_input.setText(parts[0])
        self.text_input.setPlainText(parts[1])
        
        if parts[2] in LABELS:
            self.label_group.button(LABELS.index(parts[2])).setChecked(True)
        else:
            self.label_group.button(0).setChecked(True)
            
        self.punchline_input.setPlainText(parts[3])
        self.page_number.setText(f"Page: {self.index + 1}/{max(self.index + 1, len(self.data))}")

    # Button handlers
    def create_file(self):
        file_path = self.file_path_input.text().strip()
        if not file_path:
            QMessageBox.warning(self, "Error", "Please enter a valid file name to create.")
            return
        self.initialize(file_path, True)

    def load_file(self):
        file_path = self.file_path_input.text().strip()
        if not os.path.exists(file_path):
            QMessageBox.warning(self, "Error", "File does not exist.")
            return
        self.initialize(file_path, False)

    def clean_text(self, text):
    # Remove extra whitespace, tabs, and newlines from a string
        text = text.replace('\n', ' ').replace('\t', ' ')
        return re.sub(r'\s+', ' ', text).strip()

    def clean_text_input(self):
        cleaned = self.clean_text(self.text_input.toPlainText())
        self.text_input.setPlainText(cleaned)

    def save_entry(self):
        if not self.file_path:
            QMessageBox.warning(self, "Error", "No file selected.")
            return
            
        title = self.clean_text(self.title_input.text())
        text = self.clean_text(self.text_input.toPlainText())
        label = LABELS[self.label_group.checkedId()]
        punchline = self.clean_text(self.punchline_input.toPlainText())
        
        line = f"{title}\t{text}\t{label}\t{punchline}"
        if self.index < len(self.data):
            self.data[self.index] = line
        else:
            self.data.append(line)
        
        self.save_data(self.file_path, self.data)
        QMessageBox.information(self, "Saved", f"Saved line {self.index + 1}")

    def go_prev(self):
        if self.index > 0:
            self.index -= 1
            self.update_fields()

    def go_next(self):
        if self.index < len(self.data):
            self.index += 1
            self.update_fields()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AnnotationTool()
    window.show()
    sys.exit(app.exec_())