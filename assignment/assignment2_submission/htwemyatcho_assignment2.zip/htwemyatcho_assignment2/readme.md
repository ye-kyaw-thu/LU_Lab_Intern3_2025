# Cartoon Understanding with LLMs

This project explores how well different LLMs understand cartoons without text.

## What I Did

- Selected **12 cartoons** (some from Myanmar) without text to test visual interpretation.
- Used **three models**:

  - chatGPT (free)
  - Gemini 2.5 Flash
  - Claude Sonnet4

- Generated **captions (≤12 words)** and **descriptions (2–3 sentences)** in **English, Japanese, Chinese, Myanmar** using the same prompt.
- Used **GPT-5 (paid)** as the reference “true label” for evaluation.

## Evaluation

- Measured model performance with:

  - **BLEU**: word overlap
  - **ROUGE-L**: sentence similarity
  - **Cosine similarity**: semantic similarity

### Average Scores

| Model   | BLEU   | ROUGE-L | CosineSim |
| ------- | ------ | ------- | --------- |
| Gemini  | 0.0288 | 0.1916  | 0.1689    |
| Claude  | 0.0094 | 0.0578  | 0.0612    |
| chatGPT | 0.0420 | 0.2405  | 0.1731    |

### Findings

- **chatGPT** scored the highest across all three metrics, showing the best overall alignment with the reference labels.
- **Gemini** performed moderately well, with good creativity but lower overlap.
- **Claude** produced diverse outputs but had the lowest scores on all metrics.

Overall, **chatGPT demonstrated the strongest cartoon understanding**, while Gemini and Claude lagged behind in both accuracy and semantic similarity.
