Files
Assignment02/
├─ cartoons/
│    ├─ Originals
├─ ChatGPT.txt
├─ Claude.txt
├─ Evaluations.xlsx
├─ Gemini.txt
├─ Readme.txt

Assignment ၂ ကိုတော့ လူ့စိတ်နေစိတ်ထား၊ နိုင်ငံရေးကို မူတည်ပြီး ရွေးချယ်ဖြစ်ခဲ့ပါတယ်။ မြန်မာနိုင်ငံရဲ့ ကာတွန်းတစ်ပုံကိုလည်း ရွေးချယ်ဖြစ်ခဲ့ပါတယ်။ 

Model တွေကိုတော့ Claude Sonnet 4.0, ChatGPT 5.0, Gemini 2.5 ကိုသုံးခဲ့ပါတယ်။

Originals ကာတွန်းတွေကို Model သုံးခုနဲ့ ထုတ်ပြီးတဲ့နောက်မှာတော့ အရင်ဆုံး Human Evaluations ကို ကိုယ်တိုင်လုပ်ခဲ့ပြီး (1-10) လုပ်ခဲ့ပါတယ်။ ChatGPT က အကောင်းဆုံးဖြစ်တယ်လို့ တွေ့ရပါတယ်။

နောက်တစ်ခုကတော့ စဥ်းစားမိတဲ့ နည်းတစ်ခုကို စမ်းခဲ့ပါတယ်။ အရင်ဆုံး Model တိုင်းက ထုတ်ပေးတဲ့ Captions တွေကို အဆိုပါ Model ကိုပဲ ပြန်ပြီး Image Generate ထုတ်ခိုင်းခဲ့ပါတယ်။ သုံးခဲ့တဲ့ Prompt ကတော့ "You are a professional cartoonist. From now on I will give you text prompts and you will generate image without text caption. You can only use any kind of cartoon drawing styles to generate cartoons."

အဲ့ဒီနောက် Model အချင်းချင်း Evalution ပတ်လည်ပေးခိုင်းတာမျိုးပါ။ ဥပမာ -ChatGPT က ထုတ်ပေးတဲ့ ပုံတွေနဲ့ Original ပုံတွေကို ChatGPT ထိုးပေးတုန်းက ရလာတဲ့ Captions ကို Cluade ကိုပေးပြီး တူညီမှု ရှိမရှိ စစ်ခိုင်းတာမျိုးပါ။
အဲ့ဒီအတွက် သုံးခဲ့တဲ့ Prompt ကတော့ "From now on I will give you a photo of cartoon and a caption for it. You will give feed back about how much the photo and caption are correspond to each other.
from scale 1-10. Being 1 is the worst and 10 is the best." ပါ။ Claude က Average အများဆုံးရသွားပါတယ်။

ထူးခြားချက်အနေနဲ့ကတော့ ChatGPTနဲ့ Claude မှာနိုင်ငံရေး(အထူးသဖြင့် မဲပေးတာတွေ၊ မြန်မာနိုင်ငံအကြောင်းကာတွန်း(cartoon06.png) မှာဆိုရင် အင်္ဂလိပ်လို Prompt မှာ Evaluation လုပ်ပေးမဘဲ ဂျပန်လို စာပြောင်းပေးလိုက်တဲ့အခါမှာတော့ အဆင်ပြေသွားတာတွေ့ရပါတယ်။ ChatGPT အနေနဲ့ အရှေ့ပုံတွေက ပါတဲ့ Object တွေကို နောက်ပုံတွေမှာ မဆိုင်ဘဲ ပြန်သုံးတာတွေ တွေ့ရပါတယ်။

Model တွေအားလုံးကို Memory မှတ်ထားတာမျိုးမရှိအောင် Generate လုပ်တဲ့အခါရော၊ Evaluation လုပ်တဲ့အခါမှာပါ မတူညီတဲ့အကောင့်တွေကို သုံးခဲ့ပါတယ်။

AI တွေက ထုတ်ပေးတဲ့ ပုံတွေကိုတော့ Discord က File Size Limit ကြောင့် "https://drive.google.com/drive/folders/145Cdem2QHpPmN7BXI5RKOz0lbpAWiii6?usp=sharing" မှာတင်ထားပါတယ်ဆရာ။




