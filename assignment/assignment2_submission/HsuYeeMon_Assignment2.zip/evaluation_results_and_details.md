Evaluation လုပ်ဖို့ အတွက်ကို Criteria ၃ ခုကို rating သတ်မှတ်ပေးပြီးတော့ သုံးခုရဲ့ average ကို Score အနေနဲ့ သတ်မှတ်ထားပါတယ်။ 
ပုံတွေကို ‌ရွေးတဲ့ နေရာမှာ စာပါတဲ့နေတဲ့ အပိုင်းတွေကို cropped လုပ်ခဲ့တာတွေလုပ်ခဲ့ပါတယ်။ 

Criteria ၃ ခုစီမှာ rating သတ်မှတ်ရလွယ်အောင် ၊ rubric တွေ သတ်မှတ်ထားပါတယ်။ 

1. Relevance
5 – Fully relevant to the image
4 – Mostly relevant, minor issues
3 – Partly relevant, misses some aspects
2 – Mostly irrelevant, only small part matches
1 – Completely irrelevant

2. Accuracy
5 – All items, background, and main context are correct
4 – Mostly correct, minor mistakes
3 – Some errors in objects, background, or context
2 – Many errors, few correct details
1 – Almost everything inaccurate

3. Detail (for Description)

5 – Clear and specific details provided , and include the inferred meaning that the cartoon capture
4 – Good detail, minor gaps
3 – Basic detail, misses some key points
2 – Very limited detail, vague description
1 – No meaningful detail


# Image Captioning Evaluation Summary

## Overall Performance (Min, Max, Average of Total Score)
| Model   | Min Score | Max Score | Avg. Score |
|---------|-----------|-----------|------------|
| ChatGPT | 3.0       | 5.0       | 4.4        |
| Claude  | 1.7       | 5.0       | 4.1        |
| Gemini  | 4.0       | 5.0       | 4.6        |

ပုံ ၁၂ ပုံမှာ overall အနေနဲ့ Gemini က average 4.6 အနေနဲ့ အမြင့်ဆုံးရခဲ့ပါတယ်။ 


## Comparison of Average Rating by Metrics
| Model   | Relevance (1–5) | Accuracy (1–5) | Detail (1–5) |
|---------|-----------------|----------------|--------------|
| ChatGPT | 4.6             | 4.3            | 4.4          |
| Claude  | 4.2             | 3.9            | 4.3          |
| Gemini  | 4.8             | 4.7            | 4.4          |