import json
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from bert_score import score as bert_score
import pandas as pd

with open('ChatGPT_5.json', 'r', encoding="utf-8") as file:
    chat = json.load(file)
with open('Claude_Sonnet4.json', 'r', encoding="utf-8") as file:
    claude = json.load(file)
with open('Gemini_2.5Flash.json', 'r', encoding="utf-8") as file:
    gemini = json.load(file)


chat_cap = [pic['caption']['en'] for pic in chat]
chat_desc = [pic['description']['en'] for pic in chat]
claude_cap = [pic['caption']['en'] for pic in claude]
claude_desc = [pic['description']['en'] for pic in claude]
gemini_cap = [pic['caption']['en'] for pic in gemini]
gemini_desc = [pic['description']['en'] for pic in gemini]

smoothie = SmoothingFunction().method1

def compute_scores(ref_caps, hyp_caps, ref_descs, hyp_descs, ref_name, hyp_name):
    rows = []
    n = len(ref_caps)
    
    cap_preds, cap_refs = hyp_caps, ref_caps
    desc_preds, desc_refs = hyp_descs, ref_descs
    
    cap_p, cap_r, cap_f1 = bert_score(cap_preds, cap_refs, lang='en', rescale_with_baseline=True)
    desc_p, desc_r, desc_f1 = bert_score(desc_preds, desc_refs, lang='en', rescale_with_baseline=True)

    cap_f1 = cap_f1.clamp(min=0.0)
    desc_f1 = desc_f1.clamp(min=0.0)
    
    for i in range(n):
        cap_bleu = sentence_bleu([ref_caps[i].split()], hyp_caps[i].split(), smoothing_function=smoothie)
        desc_bleu = sentence_bleu([ref_descs[i].split()], hyp_descs[i].split(), smoothing_function=smoothie)
        
        rows.append({
            "image": f"c{i+1:03}",
            "comparison": f"{ref_name}_vs_{hyp_name}",
            "cap_bleu": cap_bleu,
            "cap_bertscore_f1": cap_f1[i].item(),
            "desc_bleu": desc_bleu,
            "desc_bertscore_f1": desc_f1[i].item()
        })
    return rows

pairs = [
    ("chat", "claude"),
    ("claude", "gemini"),
    ("gemini", "chat"),
]

all_rows = []
for ref, hyp in pairs:
    all_rows.extend(compute_scores(
        globals()[f"{ref}_cap"], globals()[f"{hyp}_cap"],
        globals()[f"{ref}_desc"], globals()[f"{hyp}_desc"],
        ref, hyp
    ))

df = pd.DataFrame(all_rows)
# print(df)
df.to_excel("evaluation.xlsx", index=False)

