# Cartoon Caption & Description Evaluation

## Choosing LLMs
The following LLMs were used for generating captions and descriptions:

1. **Gemini 2.5 Pro** — Selected for its strong multimodal reasoning.  
2. **ChatGPT** (model unspecified due to website interface changes).  
3. **Grok-4** — Included for comparison.  

Other models considered:  
- **Deepseek**: Rejected because it does not directly process images (only OCR text extraction).  
- **Qwen**: Excluded due to consistently poor performance on this task.  

## Choosing Cartoons
Cartoons were chosen across three thematic categories to test factual grounding and interpretative ability:  

- `C001.jpg` – `C007.jpg` : **Political cartoons**  
- `C008.jpg` – `C009.jpg` : **Environmental cartoons**  
- `C010.jpg` – `C012.jpg` : **Thoughtful cartoons**  

## Evaluation

### 1. CLIP-score
We compute semantic similarity between the image and generated text using CLIP.  

```python
def get_clip_score(image: Image.Image, text: str) -> float:
    """
    Calculates the normalized CLIP score (cosine similarity) between an image and a text caption,
    scaled to a [0, 1] range.
    """
    inputs = processor(text=text, images=image, return_tensors="pt", padding=True, truncation=True)
    with torch.no_grad():
        outputs = model(**inputs)

    cosine_similarity = outputs.logits_per_image[0][0] / model.logit_scale.exp()
    normalized_score = (cosine_similarity + 1) / 2
    return normalized_score.item()

```
### 2.Human evaluation 

1. Factual Accuracy

How well the output reflects the actual facts in the image.

0 — Completely wrong (no correct facts).
1 — Less than 50% of the facts are true.
2 — At least 50% of the facts are true.
3 — Mostly accurate (over 90% true).
4 — Highly accurate with detailed correctness.

2. Interpretation

How well the output interprets or explains the situation in the image.

0 — No interpretation provided.
1 — Incorrect or misleading interpretation.
2 — Partially correct interpretation (some truth, but incomplete).
3 — Mostly correct interpretation (clear and relevant).
4 — Excellent interpretation with nuance and meaningful insight.

